package mx.edu.ittepic.judamedranoba.sqlite;

/**
 * Created by JuanDaniel on 30/08/17.
 */

public class Lista_entrada {
    private String textoEncima;
    private String textoMedio;
    private String textoDebajo;
    private String textoSAbajo;

    public Lista_entrada(String textoEncima, String textoMedio ,String textoDebajo,String textoSabajo) {
        this.textoEncima = textoEncima;
        this.textoMedio = textoMedio;
        this.textoDebajo = textoDebajo;
        this.textoSAbajo = textoSabajo;
    }

    public String get_textoEncima() {
        return textoEncima;
    }

    public String get_textoMedio() {return textoMedio; }

    public String get_textoDebajo() {
        return textoDebajo;
    }

    public String get_textoSabajo() {return textoSAbajo; }

}
