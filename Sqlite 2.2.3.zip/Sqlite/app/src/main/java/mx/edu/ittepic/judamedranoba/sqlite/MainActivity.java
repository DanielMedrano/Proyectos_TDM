package mx.edu.ittepic.judamedranoba.sqlite;

import android.content.Intent;
import android.database.Cursor;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView Lv;
    ArrayList<Lista_entrada> datos;
    FloatingActionButton btnAdd;
    FloatingActionButton btnEdit;
    FloatingActionButton btnDel;
    int Posision = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = (FloatingActionButton) findViewById(R.id.fab_add);
        btnEdit = (FloatingActionButton) findViewById(R.id.fab_edit);
        btnDel = (FloatingActionButton) findViewById(R.id.fab_delete);

        btnEdit.hide();
        btnDel.hide();

        datos = new ArrayList<Lista_entrada>();

        // Instanciar clase DBAdapter
        final DBAdapter db = new DBAdapter(this);

        ExplorandoBD();

        Lv = (ListView) findViewById(R.id.lv);
        LlenandoLista();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Add.class);
                startActivity(intent);
            }
        });

        Lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                btnEdit.hide();
                btnDel.hide();
            }
        });

       Lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
           @Override
           public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
               btnEdit.show();
               btnDel.show();
               Posision = i;
               return true;
           }
       });

       btnDel.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               db.open();
               db.deleteContact(datos.get(Posision).get_textoEncima());
               db.close();
               Toast.makeText(getApplicationContext(),datos.get(Posision).get_textoMedio()+" se ha eliminado",Toast.LENGTH_LONG).show();
               datos.clear();
               ExplorandoBD();
               LlenandoLista();
           }
       });


       btnEdit.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String name = datos.get(Posision).get_textoMedio();
               String mail = datos.get(Posision).get_textoDebajo();
               String cel = datos.get(Posision).get_textoSabajo();
               String pos = datos.get(Posision).get_textoEncima();

               Intent intent = new Intent(MainActivity.this, Edit.class);
               intent.putExtra("posicion", pos);
               intent.putExtra("nombre", name);
               intent.putExtra("email", mail);
               intent.putExtra("celular", cel);
               startActivity(intent);
           }
       });

    }

    public void  LlenandoLista(){
        Lv.setAdapter(new Lista_adaptador(this, R.layout.entrada, datos){
            @Override
            public void onEntrada(Object entrada, View view) {
                if (entrada != null) {
                    TextView texto_superior_entrada = (TextView) view.findViewById(R.id.textView_superior);
                    if (texto_superior_entrada != null)
                        texto_superior_entrada.setText(((Lista_entrada) entrada).get_textoEncima());

                    TextView texto_inferior_entrada = (TextView) view.findViewById(R.id.textView_inferior);
                    if (texto_inferior_entrada != null)
                        texto_inferior_entrada.setText(((Lista_entrada) entrada).get_textoMedio());

                    TextView texto_debajo_entrada = (TextView) view.findViewById(R.id.textView_bajo);
                    if (texto_debajo_entrada != null)
                        texto_debajo_entrada.setText(((Lista_entrada) entrada).get_textoDebajo());

                    TextView texto_sabajo_entrada = (TextView) view.findViewById(R.id.textView_sabajo);
                    if (texto_sabajo_entrada != null)
                        texto_sabajo_entrada.setText(((Lista_entrada) entrada).get_textoSabajo());
                }
            }
        });
    }

    public void ExplorandoBD(){
        final DBAdapter db = new DBAdapter(this);
        db.open();
        // Explorar el cursor
        Cursor c = db.getAllContacts();
        if (c.moveToFirst()) {
            do {
                datos.add(new Lista_entrada(c.getString(0),c.getString(1),c.getString(2),c.getString(3)));
            } while (c.moveToNext());
        }
        db.close();
    }

}