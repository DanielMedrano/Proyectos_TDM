package mx.edu.ittepic.judamedranoba.sqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add extends AppCompatActivity {

    EditText Nombre;
    EditText Email;
    EditText Celular;
    Button Guardar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Nombre = (EditText) findViewById(R.id.edt_nom);
        Email = (EditText) findViewById(R.id.edt_email);
        Celular = (EditText) findViewById(R.id.edt_cel);

        Guardar = (Button) findViewById(R.id.btn_gdar);

        Guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Guardado",Toast.LENGTH_SHORT).show();
            }
        });

    }
}
