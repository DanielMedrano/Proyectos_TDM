package mx.edu.ittepic.judamedranoba.sqlite;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView Lv;
    ArrayList<Lista_entrada> datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        datos = new ArrayList<Lista_entrada>();

        // Instanciar clase DBAdapter
        DBAdapter db = new DBAdapter(this);

        db.open();
        // Explorar el cursos
        Cursor c = db.getAllContacts();
        if (c.moveToFirst()) {
            do {
                datos.add(new Lista_entrada("Id: "+c.getString(0),"Nombre: "+c.getString(1),"Email: "+c.getString(2)));
            } while (c.moveToNext());
        }
        db.close();

        Lv = (ListView) findViewById(R.id.lv);
        Lv.setAdapter(new Lista_adaptador(this, R.layout.entrada, datos){
            @Override
            public void onEntrada(Object entrada, View view) {
                if (entrada != null) {
                    TextView texto_superior_entrada = (TextView) view.findViewById(R.id.textView_superior);
                    if (texto_superior_entrada != null)
                        texto_superior_entrada.setText(((Lista_entrada) entrada).get_textoEncima());

                    TextView texto_inferior_entrada = (TextView) view.findViewById(R.id.textView_inferior);
                    if (texto_inferior_entrada != null)
                        texto_inferior_entrada.setText(((Lista_entrada) entrada).get_textoMedio());

                    TextView texto_debajo_entrada = (TextView) view.findViewById(R.id.textView_bajo);
                    if (texto_debajo_entrada != null)
                        texto_debajo_entrada.setText(((Lista_entrada) entrada).get_textoDebajo());
                }
            }
        });

    }
}