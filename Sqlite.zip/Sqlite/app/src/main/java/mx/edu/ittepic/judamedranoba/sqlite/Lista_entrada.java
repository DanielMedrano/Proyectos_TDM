package mx.edu.ittepic.judamedranoba.sqlite;

/**
 * Created by JuanDaniel on 30/08/17.
 */

public class Lista_entrada {
    private String textoEncima;
    private String textoMedio;
    private String textoDebajo;

    public Lista_entrada(String textoEncima, String textoMedio ,String textoDebajo) {
        this.textoEncima = textoEncima;
        this.textoMedio = textoMedio;
        this.textoDebajo = textoDebajo;
    }

    public String get_textoEncima() {
        return textoEncima;
    }

    public String get_textoMedio() {return textoMedio; }

    public String get_textoDebajo() {
        return textoDebajo;
    }

}
